<style scoped>
.list {}
view, input {
    font-size: 30rpx;
}
</style>

<template>
  <div>
    <div class="hr20"></div>
    <div class="tool-list mt70" v-if="list.length > 0">
      <a v-for="item in list"
         :key="id"
         :href="item.href"
         class="tool-item">
        <img :src="imgSrc + item.imgpath" mode="aspectFill" />
        <div>{{item.name}}</div>
      </a>
    </div>
    <div class="empty" v-else>
      没有任何信息
    </div>
  </div>
</template>

<script>
import { formatUrl } from '@/utils'
import { postAction } from '@/utils/api'
export default {

  data () {
    return {
      imgSrc: mpvue.imgSrc,
      list: []
    }
  },
  methods: {
    getData () {
      postAction('my_sc').then(res => {
        if (res.ret === 0) {
          this.list = formatUrl(res.data.list)
        }
      })
    }
  },
  onShow () {
    this.getData()
  }
}
</script>
