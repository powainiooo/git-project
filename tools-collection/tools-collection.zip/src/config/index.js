export default {
  tokenKey: 'login_key',
  // baseUrl: 'https://yghzp.vsapp.cn/mobile/kservice',
  baseUrl: 'https://gjdq.vsapp.cn/api/gj/',
  imgSrc: 'https://gjdq.vsapp.cn',
  mapKey: 'H2MBZ-JZRKF-OZMJ2-NYEC7-CFOCQ-QOBLS'
}
