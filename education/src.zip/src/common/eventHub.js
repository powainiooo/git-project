import wepy from '@wepy/core'

let eventHub = new wepy()

export default eventHub
